import fs from 'node:fs';
import path from 'node:path';
const manifest=JSON.parse(fs.readFileSync('.figma-reference/assets-manifest.json','utf8'));
const missing=manifest.filter(a=>{const p=path.join('public/assets/figma',a.file);if(!fs.existsSync(p))return true;const b=fs.readFileSync(p);return b.length===0||b.subarray(0,200).toString().includes('<html');});
if(missing.length){console.error(`${missing.length} assets Figma manquants. Publication bloquée.`);process.exit(1)}
console.log(`${manifest.length} assets présents.`);
