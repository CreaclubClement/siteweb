// Source: Figma 114:2777; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgUuidC594854B938E41CdA6552Ad5Ea221458 = `${assetPathPrefix}/e2205.svg`;

type Frame440Props = {
  className?: string;
  property1?: "Default";
};

function Frame440({ className, property1 = "Default" }: Frame440Props) {
  return (
    <div className={className || "content-stretch flex flex-col items-end p-[var(--s,8px)] relative"} data-node-id="114:2845">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="114:2844">
        Expérience Digtial
      </p>
    </div>
  );
}

type Frame439Props = {
  className?: string;
  property1?: "Default";
};

function Frame439({ className, property1 = "Default" }: Frame439Props) {
  return (
    <div className={className || "content-stretch flex flex-col items-end p-[var(--s,8px)] relative"} data-node-id="114:2835">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="114:2834">
        Identité visuelle
      </p>
    </div>
  );
}

type Frame438Props = {
  className?: string;
  property1?: "Default";
};

function Frame438({ className, property1 = "Default" }: Frame438Props) {
  return (
    <div className={className || "content-stretch flex flex-col items-end p-[var(--s,8px)] relative max-w-full w-[148px]"} data-node-id="114:2829">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="114:2828">
        Stratégie de marque
      </p>
    </div>
  );
}

type HoverLinkEffectProps = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect({ className, property1 = "Default" }: HoverLinkEffectProps) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative"} data-node-id="21:1690">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1691" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1692">
        Le journal
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1693" />
    </div>
  );
}

type HoverLinkEffect1Props = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect1({ className, property1 = "Default" }: HoverLinkEffect1Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative"} data-node-id="21:1676">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1677" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1678">
        Le Studio
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1679" />
    </div>
  );
}

type HoverLinkEffect2Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

function HoverLinkEffect2({ className, property1 = "Default" }: HoverLinkEffect2Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative"} data-figma-id={isVariant2 ? "node-21_1666" : "node-21_1662"}>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-figma-id={isVariant2 ? "node-21_1667" : "node-21_1663"} />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant2 ? "node-21_1668" : "node-21_1664"}>
        Services
      </p>
      <div className={`bg-[var(--noir,#252525)] h-px relative shrink-0 ${isVariant2 ? "w-full" : "w-0"}`} data-figma-id={isVariant2 ? "node-21_1669" : "node-21_1665"} />
    </div>
  );
}

type HoverLinkEffect3Props = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect3({ className, property1 = "Default" }: HoverLinkEffect3Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[46px]"} data-node-id="21:1640">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1651" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1641">
        Projets
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1642" />
    </div>
  );
}

type LogoAnimationHeaderProps = {
  className?: string;
  property1?: "Default";
};

function LogoAnimationHeader({ className, property1 = "Default" }: LogoAnimationHeaderProps) {
  return (
    <div className={className || "h-[21.093px] relative max-w-full w-[110px]"} data-node-id="21:1612">
      <div className="absolute contents inset-[0_80.82%_0_0]" data-node-id="21:1613">
        <div className="absolute contents inset-[0_80.82%_0_0]" data-node-id="21:1614">
          <div className="absolute inset-[0_80.82%_0_0]" data-node-id="21:1615" data-name="uuid-c594854b-938e-41cd-a655-2ad5ea221458">
            <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgUuidC594854B938E41CdA6552Ad5Ea221458} />
          </div>
        </div>
      </div>
      <p className="[word-break:break-word] absolute font-['Season_VF-TRIAL:Sans_Medium'] inset-[10%_-0.48%_4.66%_26.85%] leading-[17.578px] not-italic text-[17.578px] text-[color:var(--noir,#252525)] tracking-[-0.3516px] whitespace-normal" data-node-id="21:1617">
        Étape Zero
      </p>
    </div>
  );
}

type HeaderDesktopProps = {
  className?: string;
  property1?: "Default" | "Dropdown services";
};

export default function HeaderDesktop({ className, property1 = "Default" }: HeaderDesktopProps) {
  const isDropdownServices = property1 === "Dropdown services";
  return (
    <div className={className || "bg-[var(--blanc,white)] content-stretch flex items-start justify-between px-[42px] py-[20px] relative w-full"} data-figma-id={isDropdownServices ? "node-114_2778" : "node-21_1638"}>
      <div className="absolute bg-[var(--accent,#d9ff8e)] content-stretch flex gap-[var(--xs,4px)] h-[68px] items-end p-[var(--s,8px)] right-0 rounded-bl-[var(--s,8px)] top-0 max-w-full w-[199px]" data-figma-id={isDropdownServices ? "node-114_2779" : "node-21_1840"} data-name="CTA contact Header">
        <p className="[word-break:break-word] font-sans font-normal leading-[1.2] relative shrink-0 text-[32px] text-[color:var(--noir,#252525)] text-right tracking-[-0.96px] whitespace-normal" data-figma-id={isDropdownServices ? "node-I114_2779-21_1835" : "node-I21_1840-21_1835"}>
          Contact
        </p>
        <div className="absolute bg-[var(--noir,#252525)] h-[68px] left-0 rounded-bl-[var(--s,8px)] top-0 w-0" data-figma-id={isDropdownServices ? "node-I114_2779-21_1847" : "node-I21_1840-21_1847"} />
      </div>
      <LogoAnimationHeader className="h-[21.093px] relative shrink-0 max-w-full w-[110px]" />
      <div className="content-stretch flex gap-[25px] items-center relative shrink-0" data-figma-id={isDropdownServices ? "node-114_2781" : "node-21_1597"}>
        <HoverLinkEffect3 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[46px]" />
        <div className="content-stretch flex gap-[var(--xs,4px)] items-center relative shrink-0" data-figma-id={isDropdownServices ? "node-114_2783" : "node-114_2722"}>
          <HoverLinkEffect2 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0" property1={isDropdownServices ? "Variant2" : undefined} />
          <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-black whitespace-normal" data-figma-id={isDropdownServices ? "node-114_2785" : "node-114_2712"}>
            +
          </p>
        </div>
        <HoverLinkEffect1 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0" />
        <HoverLinkEffect className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0" />
      </div>
      <div className="content-stretch flex gap-[var(--xs,4px)] items-center justify-end opacity-0 p-[var(--xs,4px)] relative shrink-0 max-w-full w-[110.4px]" data-figma-id={isDropdownServices ? "node-114_2788" : "node-21_1735"}>
        <p className="[word-break:break-word] font-sans font-[435] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] text-right whitespace-normal" data-figma-id={isDropdownServices ? "node-I114_2788-21_1726" : "node-I21_1735-21_1726"}>
          Contact
        </p>
      </div>
      {isDropdownServices && (
        <div className="absolute bg-[var(--blanc,white)] content-stretch flex flex-col items-start left-[634px] top-[55px] max-w-full w-[148px]" data-node-id="114:2859">
          <Frame438 className="content-stretch cursor-pointer flex flex-col items-end p-[var(--s,8px)] relative shrink-0 max-w-full w-[148px]" />
          <Frame439 className="content-stretch flex flex-col items-end p-[var(--s,8px)] relative shrink-0" />
          <Frame440 className="content-stretch flex flex-col items-end p-[var(--s,8px)] relative shrink-0" />
        </div>
      )}
    </div>
  );
}