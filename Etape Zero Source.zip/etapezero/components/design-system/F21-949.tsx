// Source: Figma 21:949; fluid layout adaptation.
type CardProjetHomeVersion2Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardProjetHomeVersion2({ className, property1 = "Default" }: CardProjetHomeVersion2Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-21_950" : "node-21_948"}>
      <div className={`aspect-[315/389] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-21_951" : "node-21_947"}>
        <div className={`content-stretch flex items-center ${isVariant2 ? "relative shrink-0" : "absolute left-[194px] top-[391px]"}`} data-figma-id={isVariant2 ? "node-21_952" : "node-21_943"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-21_953" : "node-21_944"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_954" : "node-21_945"}>
              Identité visuelle
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_955" : "node-21_922"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-21_956" : "node-21_923"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_957" : "node-21_924"}>
            Decibell
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_958" : "node-21_925"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-21_959" : "node-21_926"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] min-w-full relative shrink-0 text-[#5e5e5e] text-[16px] w-[min-content]" data-figma-id={isVariant2 ? "node-21_960" : "node-21_927"}>
          Clarifier un positionnement complexe pour le rendre immédiatement identifiable.
        </p>
      </div>
    </div>
  );
}