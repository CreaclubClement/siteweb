// Source: Figma 127:2660; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgRectangle30 = `${assetPathPrefix}/e77e6.png`;

type Frame427322456Props = {
  className?: string;
  property1?: "On click" | "Default";
};

export default function Frame427322456({ className, property1 = "Default" }: Frame427322456Props) {
  const isOnClick = property1 === "On click";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative w-full"} data-figma-id={isOnClick ? "node-127_2698" : "node-127_2661"}>
      <div className={`absolute left-0 top-[199px] w-full ${isOnClick ? "bg-[#d9ff8e] h-[348px]" : "bg-[var(--accent,#d9ff8e)] h-px"}`} data-figma-id={isOnClick ? "node-127_2699" : "node-127_2662"} />
      <div className="content-stretch flex flex-col gap-[var(--xl,40px)] items-start justify-center relative min-w-0 w-full" data-figma-id={isOnClick ? "node-127_2700" : "node-127_2663"}>
        <div className="content-stretch flex flex-col gap-[var(--m,16px)] items-start justify-center relative min-w-0 w-full" data-figma-id={isOnClick ? "node-127_2701" : "node-127_2664"}>
          <div className="h-[200px] relative min-w-0 w-full" data-figma-id={isOnClick ? "node-127_2702" : "node-127_2665"}>
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle30} />
          </div>
          <div className="grid-rows-[max-content] inline-grid leading-[0] place-items-start relative min-w-0 w-full" data-figma-id={isOnClick ? "node-127_2703" : "node-127_2666"}>
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)] text-left w-full" data-figma-id={isOnClick ? "node-127_2704" : "node-127_2667"}>
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-figma-id={isOnClick ? "node-127_2705" : "node-127_2668"}>
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-figma-id={isOnClick ? "node-127_2706" : "node-127_2669"}>{`Comprendre avant d'agir.`}</p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-figma-id={isOnClick ? "node-127_2707" : "node-127_2670"}>
                  Stratégie de marque
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-figma-id={isOnClick ? "node-127_2708" : "node-127_2671"}>
                Avant de créer une identité ou un site, nous clarifions votre positionnement, votre vision et la perception que votre entreprise souhaite construire.
              </p>
            </div>
          </div>
        </div>
        <div className="[word-break:break-word] font-sans font-normal leading-[0] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] text-left whitespace-normal" data-figma-id={isOnClick ? "node-127_2709" : "node-127_2672"}>
          <p className="leading-[1.4] mb-0">Naming</p>
          <p className="leading-[1.4] mb-0">Manifeste</p>
          <p className="leading-[1.4] mb-0">Copywriting</p>
          <p className="leading-[1.4] mb-0">Plateforme de marque</p>
          <p className="leading-[1.4] mb-0">Personnalité</p>
          <p className="leading-[1.4] mb-0">{`raison d'être`}</p>
          <p className="leading-[1.4]">concept de marque</p>
        </div>
      </div>
    </div>
  );
}