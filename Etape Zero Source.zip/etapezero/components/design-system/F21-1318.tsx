// Source: Figma 21:1318; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgUuidC594854B938E41CdA6552Ad5Ea221458 = `${assetPathPrefix}/bb5ef.svg`;

type Frame426Props = {
  className?: string;
  property1?: "Default";
};

function Frame426({ className, property1 = "Default" }: Frame426Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[110px]"} data-node-id="21:1545">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] max-w-full w-[110px]" data-node-id="21:1546">
        Mentions légales
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1547" />
    </div>
  );
}

type LogoAnimationHeaderProps = {
  className?: string;
  property1?: "Default";
};

function LogoAnimationHeader({ className, property1 = "Default" }: LogoAnimationHeaderProps) {
  return (
    <div className={className || "h-[26.475px] relative max-w-full w-[138.065px]"} data-node-id="21:1565">
      <div className="absolute contents inset-[0_80.82%_0_0]" data-node-id="21:1560">
        <div className="absolute contents inset-[0_80.82%_0_0]" data-node-id="21:1561">
          <div className="absolute inset-[0_80.82%_0_0]" data-node-id="21:1562" data-name="uuid-c594854b-938e-41cd-a655-2ad5ea221458">
            <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgUuidC594854B938E41CdA6552Ad5Ea221458} />
          </div>
        </div>
      </div>
      <p className="[word-break:break-word] absolute font-['Season_VF-TRIAL:Sans_Medium'] inset-[10%_0_3.12%_26.85%] leading-[22.062px] not-italic text-[22.062px] text-[color:var(--noir,#252525)] tracking-[-0.4412px] whitespace-normal" data-node-id="21:1564">
        Étape Zero
      </p>
    </div>
  );
}

type Frame425Props = {
  className?: string;
  property1?: "Default";
};

function Frame425({ className, property1 = "Default" }: Frame425Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[55px]"} data-node-id="21:1530">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1531">
        LinkedIn
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1532" />
    </div>
  );
}

type Frame424Props = {
  className?: string;
  property1?: "Default";
};

function Frame424({ className, property1 = "Default" }: Frame424Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[53px]"} data-node-id="21:1516">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1517">
        Youtube
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1518" />
    </div>
  );
}

type Frame423Props = {
  className?: string;
  property1?: "Default";
};

function Frame423({ className, property1 = "Default" }: Frame423Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[66px]"} data-node-id="21:1502">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1503">
        Instagram
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1504" />
    </div>
  );
}

type Frame422Props = {
  className?: string;
  property1?: "Default";
};

function Frame422({ className, property1 = "Default" }: Frame422Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[103px]"} data-node-id="21:1481">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1482">
        Identité visuelle
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1483" />
    </div>
  );
}

type Frame421Props = {
  className?: string;
  property1?: "Default";
};

function Frame421({ className, property1 = "Default" }: Frame421Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[132px]"} data-node-id="21:1460">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] max-w-full w-[132px]" data-node-id="21:1461">
        Stratégie de marque
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1462" />
    </div>
  );
}

type Frame420Props = {
  className?: string;
  property1?: "Default";
};

function Frame420({ className, property1 = "Default" }: Frame420Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[117px]"} data-node-id="21:1437">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] min-w-full relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] w-[min-content]" data-node-id="21:1424">
        Expérience Digital
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1425" />
    </div>
  );
}

type Frame38Props = {
  className?: string;
  property1?: "Desktop Version" | "Mobile Version";
};

export default function Frame38({ className, property1 = "Desktop Version" }: Frame38Props) {
  const isMobileVersion = property1 === "Mobile Version";
  return (
    <div className={className || `content-stretch flex relative ${isMobileVersion ? "flex-col items-start px-[var(--m,16px)] w-full" : "items-center justify-center px-[42px] w-full"}`} data-figma-id={isMobileVersion ? "node-122_1739" : "node-21_1319"}>
      <div className={`content-stretch flex relative shrink-0 ${isMobileVersion ? "flex-col gap-[var(--xl,40px)] items-start py-[var(--l,24px)] w-full" : "items-center justify-between py-[32px] w-full"}`} data-figma-id={isMobileVersion ? "node-122_1740" : "node-21_1320"}>
        <div className={`content-stretch flex items-start relative shrink-0 ${isMobileVersion ? "flex-col gap-[var(--l,24px)]" : "gap-[80px]"}`} data-figma-id={isMobileVersion ? "node-122_1741" : "node-21_1321"}>
          <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start justify-center relative shrink-0" data-figma-id={isMobileVersion ? "node-122_1742" : "node-21_1322"}>
            <Frame420 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[117px]" />
            <Frame421 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[132px]" />
            <Frame422 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[103px]" />
          </div>
          <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start justify-center relative shrink-0" data-figma-id={isMobileVersion ? "node-122_1746" : "node-21_1326"}>
            <Frame423 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[66px]" />
            <Frame424 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[53px]" />
            <Frame425 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[55px]" />
          </div>
          <div className="[word-break:break-word] content-stretch flex flex-col font-sans font-[450] gap-[var(--xs,4px)] items-start justify-center leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)]" data-figma-id={isMobileVersion ? "node-122_1750" : "node-21_1330"}>
            <p className="h-[23px] relative shrink-0 max-w-full w-[127px]" data-figma-id={isMobileVersion ? "node-122_1751" : "node-21_1331"}>
              Clément LE BAILLIF
            </p>
            <p className="h-[23px] relative shrink-0 max-w-full w-[132px]" data-figma-id={isMobileVersion ? "node-122_1752" : "node-21_1332"}>
              Fondateur du Studio
            </p>
            <p className="h-[23px] relative shrink-0 max-w-full w-[158px]" data-figma-id={isMobileVersion ? "node-122_1753" : "node-21_1333"}>
              contact@etapezero.com
            </p>
          </div>
          <div className="[word-break:break-word] content-stretch flex flex-col font-sans font-[450] gap-[8px] h-[55.784px] items-start leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)]" data-figma-id={isMobileVersion ? "node-122_1754" : "node-21_1334"}>
            <p className="h-[23px] relative min-w-0 w-full" data-figma-id={isMobileVersion ? "node-122_1755" : "node-21_1335"}>
              Lyon
            </p>
            <p className="h-[23px] relative shrink-0 text-center w-full" data-figma-id={isMobileVersion ? "node-122_1756" : "node-21_1336"}>
              15 : 32 : 00
            </p>
          </div>
        </div>
        <div className={`content-stretch flex flex-col gap-[24px] relative shrink-0 ${isMobileVersion ? "items-start w-full" : "items-end"}`} data-figma-id={isMobileVersion ? "node-122_1757" : "node-21_1337"}>
          <LogoAnimationHeader className="h-[26.475px] relative shrink-0 max-w-full w-[138.065px]" />
          <div className="content-stretch flex gap-[12px] items-start relative shrink-0" data-figma-id={isMobileVersion ? "node-122_1759" : "node-21_1344"}>
            <Frame426 className="content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative shrink-0 max-w-full w-[110px]" />
            <p className="[word-break:break-word] font-sans font-[450] h-[23px] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] max-w-full w-[114px]" data-figma-id={isMobileVersion ? "node-122_1761" : "node-21_1346"}>
              @2026EtapeZero
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}