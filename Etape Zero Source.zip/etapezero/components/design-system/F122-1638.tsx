// Source: Figma 122:1638; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame373 = `${assetPathPrefix}/338b9.png`;

type Frame427322453Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame427322453({ className, property1 = "Default" }: Frame427322453Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-122_1654" : "node-122_1639"}>
      <div className={`h-[389px] relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : "overflow-clip"}`} data-figma-id={isVariant2 ? "node-122_1655" : "node-122_1640"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame373} />
        <div className={`content-stretch flex gap-[12px] ${isVariant2 ? "flex-col items-end justify-end relative shrink-0" : "absolute items-center left-[282px] top-[391px]"}`} data-figma-id={isVariant2 ? "node-122_1656" : "node-122_1641"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1657" : "node-122_1642"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1658" : "node-122_1643"}>
              Identité visuelle
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1659" : "node-122_1644"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1660" : "node-122_1645"}>
              Stratégie de marque
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1661" : "node-122_1646"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1662" : "node-122_1647"}>
              Expérience digitale
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-figma-id={isVariant2 ? "node-122_1663" : "node-122_1648"}>
        <div className="content-stretch flex gap-[12px] items-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-122_1664" : "node-122_1649"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1665" : "node-122_1650"}>
            PB cosmetics
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-122_1666" : "node-122_1651"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-122_1667" : "node-122_1652"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] relative shrink-0 text-[#5e5e5e] text-[16px] w-full" data-figma-id={isVariant2 ? "node-122_1668" : "node-122_1653"}>{`Faire évoluer la perception d'une marque grâce à une identité plus premium.`}</p>
      </div>
    </div>
  );
}