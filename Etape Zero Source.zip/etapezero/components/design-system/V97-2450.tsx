const assetPathPrefix = "/assets/figma";
const imgRectangle30 = `${assetPathPrefix}/e77e6.png`;

type CardServiceStrategieDeMarqueDesktopPageAProposProps = {
  className?: string;
  property1?: "Variant2";
};

export default function CardServiceStrategieDeMarqueDesktopPageAPropos({ className, property1 = "Variant2" }: CardServiceStrategieDeMarqueDesktopPageAProposProps) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative"} data-node-id="97:2450">
      <div className="absolute bg-[var(--accent,#d9ff8e)] h-[200px] left-[353px] top-0 w-0" data-node-id="97:2451" />
      <div className="content-center flex flex-wrap gap-y-[173px] items-center relative shrink-0" data-node-id="97:2452">
        <div className="content-stretch flex gap-[var(--l,24px)] items-center relative shrink-0" data-node-id="97:2453">
          <div className="h-[200px] relative min-w-0 w-full" data-node-id="97:2454">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle30} />
          </div>
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-node-id="97:2455">
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)]" data-node-id="97:2456">
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-node-id="97:2457">
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-node-id="97:2458">{`Comprendre avant d'agir.`}</p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-node-id="97:2459">
                  Stratégie de marque
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-node-id="97:2460">
                Avant de créer une identité ou un site, nous clarifions votre positionnement, votre vision et la perception que votre entreprise souhaite construire.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}