// Source: Figma 77:2045; fluid layout adaptation.
type FiltreRebrandingProps = {
  className?: string;
  property1?: "Sélectionner" | "Non sélectioner";
};

function FiltreRebranding({ className, property1 = "Sélectionner" }: FiltreRebrandingProps) {
  const isNonSelectioner = property1 === "Non sélectioner";
  return (
    <div className={className || "content-stretch flex flex-col items-start relative"} data-figma-id={isNonSelectioner ? "node-36_4879" : "node-36_4873"}>
      <div className={`content-stretch flex items-center px-[var(--s,8px)] py-[var(--xs,4px)] relative shrink-0 ${isNonSelectioner ? "bg-[var(--gris-clair,#ededed)]" : "bg-[var(--noir,#252525)] gap-[var(--s,8px)]"}`} data-figma-id={isNonSelectioner ? "node-36_4880" : "node-36_4874"}>
        <p className={`[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] whitespace-normal ${isNonSelectioner ? "text-black" : "text-[color:var(--blanc,white)]"}`} data-figma-id={isNonSelectioner ? "node-36_4881" : "node-36_4875"}>
          Rebranding
        </p>
      </div>
    </div>
  );
}

type FiltreListingProjetProps = {
  className?: string;
  property1?: "Default" | "Variant2" | "Variant3";
};

export default function FiltreListingProjet({ className, property1 = "Default" }: FiltreListingProjetProps) {
  const isDefault = property1 === "Default";
  const isVariant2 = property1 === "Variant2";
  const isVariant2OrVariant3 = ["Variant2", "Variant3"].includes(property1);
  const isVariant3 = property1 === "Variant3";
  return (
    <div className={className || "content-stretch flex gap-[10px] items-start overflow-clip py-[var(--m,16px)] relative"} data-figma-id={isVariant3 ? "node-77_2166" : isVariant2 ? "node-77_2053" : "node-77_2046"}>
      {isVariant2OrVariant3 && (
        <>
          <div className="content-stretch cursor-pointer flex flex-col items-start relative shrink-0" data-figma-id={isVariant3 ? "node-77_2167" : "node-77_2054"}>
            <div className="bg-[var(--gris-clair,#ededed)] content-stretch flex items-center px-[var(--s,8px)] py-[var(--xs,4px)] relative shrink-0" data-figma-id={isVariant3 ? "node-I77_2167-36_4802" : "node-I77_2054-36_4802"}>
              <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-black text-left whitespace-normal" data-figma-id={isVariant3 ? "node-I77_2167-36_4803" : "node-I77_2054-36_4803"}>
                Tous les articles
              </p>
            </div>
          </div>
          <FiltreRebranding className="content-stretch flex flex-col items-start relative shrink-0" property1={isVariant2 ? "Non sélectioner" : undefined} />
        </>
      )}
      <div className="content-stretch flex flex-col items-start relative shrink-0" data-figma-id={isVariant3 ? "node-77_2169" : isVariant2 ? "node-77_2160" : "node-77_2047"}>
        <div className={`content-stretch flex items-center px-[var(--s,8px)] py-[var(--xs,4px)] relative shrink-0 ${isVariant3 ? "bg-[var(--gris-clair,#ededed)]" : isVariant2 ? "bg-[var(--noir,#252525)] gap-[var(--s,8px)]" : "bg-[var(--noir,#252525)]"}`} data-figma-id={isVariant3 ? "node-I77_2169-36_4880" : isVariant2 ? "node-I77_2160-36_4874" : "node-I77_2047-36_4813"}>
          <p className={`[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] whitespace-normal ${isVariant3 ? "text-black" : "text-[color:var(--blanc,white)]"}`} data-figma-id={isVariant3 ? "node-I77_2169-36_4881" : isVariant2 ? "node-I77_2160-36_4875" : "node-I77_2047-36_4814"}>
            {isVariant2OrVariant3 ? "Lancement" : "Tous les projets"}
          </p>
        </div>
      </div>
      {isDefault && (
        <>
          <div className="content-stretch cursor-pointer flex flex-col items-start relative shrink-0" data-node-id="77:2048" data-name="Filtre Positionnement">
            <div className="bg-[var(--gris-clair,#ededed)] content-stretch flex items-center px-[var(--s,8px)] py-[var(--xs,4px)] relative shrink-0" data-node-id="I77:2048;36:4861">
              <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-black text-left whitespace-normal" data-node-id="I77:2048;36:4862">
                Rebranding
              </p>
            </div>
          </div>
          <div className="content-stretch flex flex-col items-start relative shrink-0" data-node-id="77:2049" data-name="Filtre rebranding">
            <div className="bg-[var(--gris-clair,#ededed)] content-stretch flex items-center px-[var(--s,8px)] py-[var(--xs,4px)] relative shrink-0" data-node-id="I77:2049;36:4880">
              <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-black whitespace-normal" data-node-id="I77:2049;36:4881">
                Lancement
              </p>
            </div>
          </div>
        </>
      )}
    </div>
  );
}