// Source: Figma 114:2830; fluid layout adaptation.
type Frame438Props = {
  className?: string;
  property1?: "Variant2" | "Default";
};

export default function Frame438({ className, property1 = "Default" }: Frame438Props) {
  if (property1 === "Variant2") {
    return (
      <div className={className || "bg-[var(--accent,#d9ff8e)] content-stretch cursor-pointer flex flex-col items-end p-[var(--s,8px)] relative max-w-full w-[148px]"} data-node-id="114:2831" data-name="Property 1=Variant2">
        <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] text-left whitespace-normal" data-node-id="114:2832">
          Stratégie de marque
        </p>
      </div>
    );
  }
  return (
    <div className={className || "content-stretch flex flex-col items-end p-[var(--s,8px)] relative max-w-full w-[148px]"} data-node-id="114:2829" data-name="Property 1=Default">
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="114:2828">
        Stratégie de marque
      </p>
    </div>
  );
}