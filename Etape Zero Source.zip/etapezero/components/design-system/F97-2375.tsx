// Source: Figma 97:2375; fluid layout adaptation.
type CardServiceIdentiteVisuelleDesktopPageAProposProps = {
  className?: string;
  property1?: "Variant2" | "Variant3";
};

export default function CardServiceIdentiteVisuelleDesktopPageAPropos({ className, property1 = "Variant2" }: CardServiceIdentiteVisuelleDesktopPageAProposProps) {
  const isVariant3 = property1 === "Variant3";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative"} data-figma-id={isVariant3 ? "node-97_2388" : "node-97_2376"}>
      <div className={`absolute bg-[var(--accent,#d9ff8e)] h-[200px] left-[353px] top-0 ${isVariant3 ? "w-full" : "w-0"}`} data-figma-id={isVariant3 ? "node-97_2389" : "node-97_2377"} />
      <div className="content-center flex flex-wrap gap-y-[173px] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-97_2390" : "node-97_2378"}>
        <div className="content-stretch flex gap-[var(--l,24px)] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-97_2391" : "node-97_2379"}>
          <div className="h-[200px] relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-97_2392" : "node-97_2380"} data-name="IMG_1473 3" />
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-figma-id={isVariant3 ? "node-97_2393" : "node-97_2381"}>
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)]" data-figma-id={isVariant3 ? "node-97_2394" : "node-97_2382"}>
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-97_2395" : "node-97_2383"}>
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-figma-id={isVariant3 ? "node-97_2396" : "node-97_2384"}>{`Comprendre avant d'agir.`}</p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-figma-id={isVariant3 ? "node-97_2397" : "node-97_2385"}>
                  Identité visuelle
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-figma-id={isVariant3 ? "node-97_2398" : "node-97_2386"}>{`Nous transformons votre stratégie en un système graphique cohérent, durable et identifiable. Une identité pensée pour accompagner la croissance de votre entreprise sur l'ensemble de ses points de contact.`}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}