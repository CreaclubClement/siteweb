// Source: Figma 97:2229; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgImg14733 = `${assetPathPrefix}/3cf9d.png`;

type CardServiceExperienceDigitalDesktopPageAProposProps = {
  className?: string;
  property1?: "Variant2" | "Variant3";
};

export default function CardServiceExperienceDigitalDesktopPageAPropos({ className, property1 = "Variant2" }: CardServiceExperienceDigitalDesktopPageAProposProps) {
  const isVariant3 = property1 === "Variant3";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative"} data-figma-id={isVariant3 ? "node-97_2242" : "node-97_2230"}>
      <div className={`absolute bg-[var(--accent,#d9ff8e)] h-[200px] left-[353px] top-0 ${isVariant3 ? "w-full" : "w-0"}`} data-figma-id={isVariant3 ? "node-97_2243" : "node-97_2231"} />
      <div className="content-center flex flex-wrap gap-y-[173px] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-97_2244" : "node-97_2232"}>
        <div className="content-stretch flex gap-[var(--l,24px)] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-97_2245" : "node-97_2233"}>
          <div className="h-[200px] relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-97_2246" : "node-97_2234"} data-name="IMG_1473 3">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImg14733} />
          </div>
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-figma-id={isVariant3 ? "node-97_2247" : "node-97_2235"}>
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)]" data-figma-id={isVariant3 ? "node-97_2248" : "node-97_2236"}>
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-97_2249" : "node-97_2237"}>
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-figma-id={isVariant3 ? "node-97_2250" : "node-97_2238"}>
                  Prolonger la marque dans le digital.
                </p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-figma-id={isVariant3 ? "node-97_2251" : "node-97_2239"}>
                  Expérience digitale
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-figma-id={isVariant3 ? "node-97_2252" : "node-97_2240"}>
                Nous concevons des expériences digitales qui traduisent votre positionnement et accompagnent vos objectifs. Chaque interface est pensée pour créer une expérience fluide, cohérente et orientée conversion.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}