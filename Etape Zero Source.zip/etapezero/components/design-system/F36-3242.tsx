// Source: Figma 36:3242; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgIcon = `${assetPathPrefix}/e7cb9.svg`;
const imgIcon1 = `${assetPathPrefix}/eb109.svg`;
const imgIcon2 = `${assetPathPrefix}/18ab9.svg`;

type DropdownsFormProps = {
  className?: string;
  property1?: "Dropdown | Focus" | "Dropdown | Open" | "Dropdown | Regular";
};

export default function DropdownsForm({ className, property1 = "Dropdown | Regular" }: DropdownsFormProps) {
  const isDropdownFocus = property1 === "Dropdown | Focus";
  const isDropdownOpen = property1 === "Dropdown | Open";
  return (
    <div className={className || `content-stretch flex flex-col items-start relative w-full ${isDropdownOpen ? "gap-[var(--s,8px)]" : "gap-[8px]"}`} data-figma-id={isDropdownOpen ? "node-36_3259" : isDropdownFocus ? "node-36_3251" : "node-36_3243"}>
      <p className={`[word-break:break-word] font-sans font-[450] relative shrink-0 text-[12px] text-[color:var(--gris,#5e5e5e)] w-full ${["Dropdown | Focus", "Dropdown | Open"].includes(property1) ? "leading-[1.4]" : "leading-[normal]"}`} data-figma-id={isDropdownOpen ? "node-36_3260" : isDropdownFocus ? "node-36_3252" : "node-36_3244"}>
        De quoi souhaitez-vous parler ?
      </p>
      {property1 === "Dropdown | Regular" && (
        <div className="bg-[var(--gris-clair,#ededed)] content-stretch cursor-pointer flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3245" data-name="Input field">
          <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3246" data-name="Text">
            <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--gris,#5e5e5e)] text-left" data-node-id="36:3247">
              Choisir un service
            </p>
            <div className="relative shrink-0 size-[24px]" data-node-id="36:3248" data-name="icon">
              <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon} />
            </div>
          </div>
        </div>
      )}
      {isDropdownFocus && (
        <div className="bg-[var(--gris-clair,#ededed)] content-stretch flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3253" data-name="Input field">
          <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3254" data-name="Text">
            <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--gris,#5e5e5e)]" data-node-id="36:3255">
              Stratégie de marque
            </p>
            <div className="relative shrink-0 size-[24px]" data-node-id="36:3256" data-name="icon">
              <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon} />
            </div>
          </div>
        </div>
      )}
      {isDropdownOpen && (
        <div className="content-stretch flex flex-col items-start relative min-w-0 w-full" data-node-id="36:3261" data-name="Dropdown options">
          <div className="bg-[var(--gris-clair,#ededed)] content-stretch flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3262" data-name="Input field">
            <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3263" data-name="Text">
              <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[#333] text-[14px]" data-node-id="36:3264">
                Stratégie de marque
              </p>
              <div className="relative shrink-0 size-[24px]" data-node-id="36:3265" data-name="icon">
                <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon1} />
              </div>
            </div>
          </div>
          <div className="bg-[var(--accent,#d9ff8e)] border border-[var(--gris-clair,#ededed)] border-solid content-stretch cursor-pointer flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3268" data-name="Option">
            <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3269" data-name="Text">
              <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--noir,#252525)] text-left" data-node-id="36:3270">
                Stratégie de marque
              </p>
              <div className="relative shrink-0 size-[24px]" data-node-id="36:3271" data-name="icon">
                <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon2} />
              </div>
            </div>
          </div>
          <div className="bg-white border border-[var(--gris-clair,#ededed)] border-solid content-stretch flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3274" data-name="Option 1">
            <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3275" data-name="Text">
              <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--noir,#252525)]" data-node-id="36:3276">
                Identité visuelle
              </p>
              <div className="relative shrink-0 size-[24px]" data-node-id="36:3277" data-name="icon">
                <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon2} />
              </div>
            </div>
          </div>
          <div className="bg-white border border-[var(--gris-clair,#ededed)] border-solid content-stretch flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3280" data-name="Option 2">
            <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3281" data-name="Text">
              <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--noir,#252525)]" data-node-id="36:3282">
                Expérience digitale
              </p>
              <div className="relative shrink-0 size-[24px]" data-node-id="36:3283" data-name="icon">
                <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon2} />
              </div>
            </div>
          </div>
          <div className="bg-white border border-[var(--gris-clair,#ededed)] border-solid content-stretch flex flex-col items-start p-[var(--s,8px)] relative min-w-0 w-full" data-node-id="36:3303" data-name="Option 3">
            <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-node-id="36:3304" data-name="Text">
              <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--noir,#252525)]" data-node-id="36:3305">
                Accompagnement global
              </p>
              <div className="relative shrink-0 size-[24px]" data-node-id="36:3306" data-name="icon">
                <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon2} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}