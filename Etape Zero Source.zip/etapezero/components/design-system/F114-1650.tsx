// Source: Figma 114:1650; fluid layout adaptation.
type Frame427322439Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame427322439({ className, property1 = "Default" }: Frame427322439Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || `border-[var(--gris-clair,#ededed)] border-b border-solid content-stretch flex flex-col gap-[var(--m,16px)] items-center justify-center relative ${isVariant2 ? "p-[var(--s,8px)]" : '[word-break:break-word] font-sans font-normal leading-[1.4] pb-[var(--m,16px)] pt-[var(--s,8px)] px-[var(--s,8px)]'}`} data-figma-id={isVariant2 ? "node-114_1654" : "node-114_1651"}>
      <p className={`relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal ${isVariant2 ? '[word-break:break-word] font-sans font-normal leading-[1.4]' : ""}`} data-figma-id={isVariant2 ? "node-114_1655" : "node-114_1652"}>
        Quelle est la différence entre stratégie de marque et identité visuelle ?
      </p>
      {property1 === "Default" && <p className="min-w-full relative shrink-0 text-[14px] text-[color:var(--gris,#5e5e5e)] text-left w-[min-content]" data-node-id="114:1653">{`La stratégie définit le fond : votre positionnement, votre différenciation et les messages qui guideront votre marque. L'identité visuelle vient ensuite traduire cette stratégie à travers un système graphique cohérent.`}</p>}
    </div>
  );
}