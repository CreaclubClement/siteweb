// Source: Figma 21:632; fluid layout adaptation.
type Frame387Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame387({ className, property1 = "Default" }: Frame387Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-21_633" : "node-21_631"}>
      <div className={`aspect-[315/389] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-21_634" : "node-21_630"}>
        <div className={`content-stretch flex flex-col gap-[12px] items-end justify-center ${isVariant2 ? "relative shrink-0" : "absolute left-[165px] top-[395px]"}`} data-figma-id={isVariant2 ? "node-21_635" : "node-21_622"}>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_636" : "node-21_623"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_637" : "node-21_624"}>
              Identité visuelle
            </p>
          </div>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_638" : "node-21_625"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_639" : "node-21_626"}>
              Stratégie de marque
            </p>
          </div>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_640" : "node-21_627"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_641" : "node-21_628"}>
              {isVariant2 ? "Expérience digitale" : "Expérience web"}
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0" data-figma-id={isVariant2 ? "node-21_642" : "node-21_607"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-21_643" : "node-21_608"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_644" : "node-21_609"}>
            U-Tragulinu
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_645" : "node-21_610"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-21_646" : "node-21_611"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] relative shrink-0 text-[#5e5e5e] text-[16px] w-full" data-figma-id={isVariant2 ? "node-21_647" : "node-21_612"}>
          Moderniser une marque historique sans perdre son authenticité corse.
        </p>
      </div>
    </div>
  );
}