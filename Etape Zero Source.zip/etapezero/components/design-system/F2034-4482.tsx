// Source: Figma 2034:4482; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgIcon = `${assetPathPrefix}/18ab9.svg`;

type OptionProps = {
  className?: string;
  property1?: "HOver" | "Classique";
};

export default function Option({ className, property1 = "HOver" }: OptionProps) {
  const isClassique = property1 === "Classique";
  return (
    <div className={className || `border border-[var(--gris-clair,#ededed)] border-solid content-stretch flex flex-col items-start p-[var(--s,8px)] relative w-full ${isClassique ? "bg-[var(--gris-clair,#ededed)]" : "bg-[var(--accent,#d9ff8e)]"}`} data-figma-id={isClassique ? "node-2034_4483" : "node-2034_4481"}>
      <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-figma-id={isClassique ? "node-2034_4484" : "node-2034_4476"} data-name="Text">
        <p className="[word-break:break-word] flex-[1_0_0] font-sans font-normal leading-[1.4] min-w-px relative text-[14px] text-[color:var(--noir,#252525)]" data-figma-id={isClassique ? "node-2034_4485" : "node-2034_4477"}>
          Moins de 5 000 €
        </p>
        <div className="relative shrink-0 size-[24px]" data-figma-id={isClassique ? "node-2034_4486" : "node-2034_4478"} data-name="icon">
          <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgIcon} />
        </div>
      </div>
    </div>
  );
}