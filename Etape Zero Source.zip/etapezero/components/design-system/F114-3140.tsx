// Source: Figma 114:3140; fluid layout adaptation.
type CardProjetHomeVersion1Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardProjetHomeVersion1({ className, property1 = "Default" }: CardProjetHomeVersion1Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-114_3152" : "node-114_3141"}>
      <div className={`h-[389px] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-114_3153" : "node-114_3142"}>
        <div className={`content-stretch flex items-center ${isVariant2 ? "relative shrink-0" : "absolute left-[194px] top-[391px]"}`} data-figma-id={isVariant2 ? "node-114_3154" : "node-114_3143"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-114_3155" : "node-114_3144"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3156" : "node-114_3145"}>
              Identité visuelle
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-114_3157" : "node-114_3146"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-114_3158" : "node-114_3147"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3159" : "node-114_3148"}>
            Decibell
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-114_3160" : "node-114_3149"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-114_3161" : "node-114_3150"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] min-w-full relative shrink-0 text-[#5e5e5e] text-[16px] w-[min-content]" data-figma-id={isVariant2 ? "node-114_3162" : "node-114_3151"}>
          Clarifier un positionnement complexe pour le rendre immédiatement identifiable.
        </p>
      </div>
    </div>
  );
}