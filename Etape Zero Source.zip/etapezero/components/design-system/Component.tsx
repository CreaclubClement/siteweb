"use client";
import {ProjectVideo} from '@/components/projects/ProjectVideo';
import {isVideoSource} from '@/lib/cms/media';
import {Children, isValidElement, type ReactNode, useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Textarea} from '@/components/ui/textarea';
import {Checkbox} from '@/components/ui/checkbox';
import {Select, SelectTrigger, SelectContent, SelectValue, SelectItem} from '@/components/ui/select';
import {RadioGroup, RadioGroupItem} from '@/components/ui/radio-group';
import {Accordion, AccordionItem, AccordionTrigger, AccordionContent} from '@/components/ui/accordion';
import {catalog, type Entry} from './catalog';

function paragraphs(node:ReactNode): ReactNode[]{
 const result:ReactNode[]=[];
 Children.forEach(node,n=>{if(isValidElement<{children?:ReactNode}>(n)){if(n.type==='p')result.push(n.props.children);else result.push(...paragraphs(n.props.children));}});
 return result;
}
const services=['Stratégie de marque','Identité visuelle','Expérience digitale','Accompagnement global'];
const budgets=['Moins de 5 000 €','5 000 – 10 000 €','10 000 – 20 000 €','À définir ensemble'];
export function FormSelect({budget=false}:{budget?:boolean}){
 const [value,setValue]=useState('');return <label className="ds-field"><span>{budget?'Votre budget':'De quoi souhaitez-vous parler ?'}</span><Select name={budget?"budget":"service"} value={value} onValueChange={setValue}><SelectTrigger className="ds-select"><SelectValue placeholder={budget?'Choisir un budget':'Choisir un service'}/></SelectTrigger><SelectContent>{(budget?budgets:services).map(s=><SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></label>;
}
export function ContactForm({variant="Default",onVariantChange}:{variant?:string;onVariantChange?:(s:string)=>void}){const [valid,setValid]=useState(false);const [expanded,setExpanded]=useState(false);const showForm=variant==="Variant2"||expanded;return <form className={"ds-contact "+(showForm?"is-open":"is-closed")} onSubmit={e=>{e.preventDefault();setValid(true);}}>
 <div className="ds-contact-intro"><img className="ds-contact-cover" src="/assets/figma/0cf98.png" alt=""/><div className="ds-contact-copy"><h2>Chaque projet commence par une conversation.</h2><p>Chaque entreprise est différente. Le premier échange nous permet de comprendre votre contexte, vos objectifs et de voir si nous sommes les bons partenaires pour vous accompagner.</p><Button type="button" className="ds-button" onClick={()=>{setExpanded(true);onVariantChange?.("Variant2");}}><img src="/assets/figma/1ff9a.png" width="18" height="18" alt=""/>Réserver un appel</Button>{!showForm&&<Button type="button" className="ds-button ds-secondary" onClick={()=>{setExpanded(true);onVariantChange?.("Variant2");}}>Nous écrire</Button>}</div></div>
 {showForm&&<div className="ds-form-fields"><h3>Nous écrire</h3>{[['Votre nom','name','text'],['Votre entreprise','company','text'],['E-mail','email','email']].map(([label,name,type])=><label className="ds-field" key={name}><span>{label}</span><Input id={name==='name'?'ds-name':undefined} name={name} type={type} required autoComplete={name==='email'?'email':name==='name'?'name':'organization'} className="ds-input" placeholder={label}/></label>)}<FormSelect/>
 {[['À quel moment se trouve votre entreprise ?',['Lancement','Rebranding','Croissance','Autres']],['Quand voulez-vous traiter le sujet ?',['Dès que possible','Dans 1 mois','Dans 3 mois','Plus tard']]].map(([title,options],idx)=><fieldset key={idx}><legend>{title as string}</legend><RadioGroup name={'question-'+idx} className="ds-radios">{(options as string[]).map((o,i)=><label key={o}><RadioGroupItem id={'radio-'+idx+'-'+i} value={o}/><span>{o}</span></label>)}</RadioGroup></fieldset>)}
 <FormSelect budget/><label className="ds-field"><span>Message supplémentaire</span><Textarea name="message" rows={6} className="ds-input" placeholder="Donnez-nous toutes les informations dont nous pourrions avoir besoin…"/></label>
 <Button type="submit" className="ds-button">Commencer la discussion</Button><p className="demo-note" role="status">{valid?'Le formulaire est valide. Aucun message n’a été envoyé.':'Formulaire de démonstration : aucun envoi.'}</p></div>}</form>}

export function DesignComponent({id,variant,onVariantChange,onActivate}:{id:string;variant?:string;onVariantChange?:(s:string)=>void;onActivate?:()=>void}){
 const entry=catalog.find(e=>e.id===id)!;const [own,setOwn]=useState(entry.defaultVariant);const [hover,setHover]=useState(false);
 const current=variant??own;const set=(v:string)=>{setOwn(v);onVariantChange?.(v);};
 const alternate=entry.variants.find(v=>v!==current)??current;
 const hoverFamily=['Projets','Articles','Boutons','Services'].includes(entry.family);
 const shown=hover&&hoverFamily?(entry.variants.find(v=>/hover|hober|variant2|active/i.test(v))??current):current;
 const C=entry.component;
 if(id==='36:3014')return <ContactForm variant={current} onVariantChange={set}/>;
 if(id==='36:3242'||id==='36:3349')return <FormSelect budget={id==='36:3349'}/>;
 if(id==='36:3479')return <label className="ds-check"><Checkbox/><span>Sélectionner</span></label>;
 if(entry.family==='FAQ'){
  const all=paragraphs((C as (p:any)=>ReactNode)({property1:'Default'}));const open=current==='Default';
  return <Accordion type="single" collapsible value={open?'answer':''} onValueChange={v=>set(v?'Default':'Variant2')}><AccordionItem value="answer" className="ds-faq"><AccordionTrigger>{all[0]}</AccordionTrigger><AccordionContent>{all.slice(1).map((p,i)=><p key={i}>{p}</p>)}</AccordionContent></AccordionItem></Accordion>;
 }
 const handle=()=>{if(onActivate)onActivate();else if(!hoverFamily)set(alternate);};
 const body=<div className={'component-render family-'+entry.family.toLowerCase()} data-component-id={id}><C property1={shown}/></div>;
 if(['Navigation','Filtres','Médias','Formulaires'].includes(entry.family))return <div className="ds-interactive" role="button" tabIndex={0} aria-label={entry.name} aria-pressed={current!==entry.defaultVariant} onClick={handle} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();handle();}}}>{body}</div>;
 return <Button type="button" variant="ghost" className="ds-component-button" aria-label={entry.name} onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)} onFocus={()=>setHover(true)} onBlur={()=>setHover(false)} onClick={handle}>{body}</Button>;
}
export type Project={id:string;title:string;category:string;description:string;cover:string;coverAlt?:string;coverPoster?:string;coverFit?:'cover'|'contain';coverPosition?:string;services:string[];href?:string;};
export function ProjectCard({project,format='wide',deferImage=false}:{project:Project;format?:'wide'|'narrow'|'large'|'listing'|'mobile';deferImage?:boolean}){
 const Tag=project.href?'a':'article';
 return <Tag href={project.href} tabIndex={project.href?undefined:0} className={'project-card project-'+format} aria-label={project.title} data-project={project.id}>
  <div className="project-cover">{!deferImage&&project.cover?isVideoSource(project.cover)?<ProjectVideo src={project.cover} poster={project.coverPoster} alt={project.coverAlt||project.title} style={{objectFit:project.coverFit||'cover',objectPosition:project.coverPosition||'center'}}/>:<img src={project.cover} alt={project.coverAlt||project.title} style={{objectFit:project.coverFit||'cover',objectPosition:project.coverPosition||'center'}}/>:<div className="project-image-pending" role="img" aria-label={'Visuel de '+project.title+' à venir'}><span>Visuel à venir</span></div>}<ul>{project.services.map(s=><li key={s}>{s}</li>)}</ul></div>
  <div className="project-heading"><strong>{project.title}</strong><span>{project.category}</span></div><p>{project.description}</p>
 </Tag>;
}
