// Source: Figma 114:3226; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame396 = `${assetPathPrefix}/77725.png`;

type Frame448Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame448({ className, property1 = "Default" }: Frame448Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-114_3238" : "node-114_3227"}>
      <div className={`h-[389px] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-114_3239" : "node-114_3228"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame396} />
        <div className={`content-stretch flex items-center ${isVariant2 ? "relative shrink-0" : "absolute left-[194px] top-[391px]"}`} data-figma-id={isVariant2 ? "node-114_3240" : "node-114_3229"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-114_3241" : "node-114_3230"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3242" : "node-114_3231"}>
              Identité visuelle
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-114_3243" : "node-114_3232"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-114_3244" : "node-114_3233"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3245" : "node-114_3234"}>
            SoleSpace
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-114_3246" : "node-114_3235"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-114_3247" : "node-114_3236"}>
              LANCEMENT
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] min-w-full relative shrink-0 text-[#5e5e5e] text-[16px] w-[min-content]" data-figma-id={isVariant2 ? "node-114_3248" : "node-114_3237"}>{`Poser les bases d'une marque ambitieuse dès son lancement.`}</p>
      </div>
    </div>
  );
}