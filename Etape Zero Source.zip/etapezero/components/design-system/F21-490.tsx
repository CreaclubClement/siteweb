// Source: Figma 21:490; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame373 = `${assetPathPrefix}/bcf19.png`;

type CardProjetHomeVersion3Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardProjetHomeVersion3({ className, property1 = "Default" }: CardProjetHomeVersion3Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-21_491" : "node-21_489"}>
      <div className={`aspect-[853/479] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-21_492" : "node-21_482"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame373} />
        <div className={`content-stretch flex gap-[12px] items-center ${isVariant2 ? "relative shrink-0" : "absolute left-[460px] top-[481px]"}`} data-figma-id={isVariant2 ? "node-21_507" : "node-21_515"}>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_508" : "node-21_516"}>
            <p className={`[word-break:break-word] font-sans font-normal relative shrink-0 text-[14px] text-black text-center whitespace-normal ${isVariant2 ? "leading-[1.4]" : "leading-[normal]"}`} data-figma-id={isVariant2 ? "node-21_509" : "node-21_517"}>
              Identité visuelle
            </p>
          </div>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_510" : "node-21_518"}>
            <p className={`[word-break:break-word] font-sans font-normal relative shrink-0 text-[14px] text-black text-center whitespace-normal ${isVariant2 ? "leading-[1.4]" : "leading-[normal]"}`} data-figma-id={isVariant2 ? "node-21_511" : "node-21_519"}>
              Stratégie de marque
            </p>
          </div>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-white" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_512" : "node-21_520"}>
            <p className={`[word-break:break-word] font-sans font-normal relative shrink-0 text-[14px] text-black text-center whitespace-normal ${isVariant2 ? "leading-[1.4]" : "leading-[normal]"}`} data-figma-id={isVariant2 ? "node-21_513" : "node-21_521"}>
              {isVariant2 ? "Expérience digitale" : "Expérience web"}
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_493" : "node-21_483"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-21_494" : "node-21_484"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_495" : "node-21_485"}>
            Amoual
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[var(--gris-clair,#ededed)]"}`} data-figma-id={isVariant2 ? "node-21_496" : "node-21_486"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-21_497" : "node-21_487"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] relative shrink-0 text-[#5e5e5e] text-[16px] w-full" data-figma-id={isVariant2 ? "node-21_498" : "node-21_488"}>{`Construire une marque capable d'inspirer confiance aux investisseurs.`}</p>
      </div>
    </div>
  );
}