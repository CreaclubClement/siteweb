// Source: Figma 36:4116; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgRectangle6 = `${assetPathPrefix}/62e58.png`;

type CardArticleV1Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardArticleV1({ className, property1 = "Default" }: CardArticleV1Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative w-full"} data-figma-id={isVariant2 ? "node-36_4130" : "node-36_4117"}>
      <div className="h-[352px] relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-36_4131" : "node-36_4118"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle6} />
      </div>
      <div className="content-stretch flex flex-col gap-[12px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-36_4132" : "node-36_4119"}>
        <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-36_4133" : "node-36_4120"}>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[var(--accent,#d9ff8e)]" : "bg-[var(--gris-clair,#ededed)]"}`} data-figma-id={isVariant2 ? "node-36_4134" : "node-36_4121"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[12px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant2 ? "node-36_4135" : "node-36_4122"}>
              IDENTITÉ VISUELLE
            </p>
          </div>
          <p className="[word-break:break-word] font-sans font-[450] leading-[1.4] relative shrink-0 text-[12px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant2 ? "node-36_4136" : "node-36_4123"}>
            12 juillet 2025
          </p>
        </div>
        <div className="content-stretch flex flex-col items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-36_4137" : "node-36_4124"}>
          <div className="[word-break:break-word] content-stretch flex flex-col font-sans gap-[12px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-36_4138" : "node-36_4125"}>
            <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 text-[14px] w-full" data-figma-id={isVariant2 ? "node-36_4139" : "node-36_4126"}>
              <p className={`font-[450] leading-[normal] relative shrink-0 text-[color:var(--noir,#252525)] w-full ${isVariant2 ? "[text-underline-position:from-font] decoration-from-font decoration-solid underline" : ""}`} data-figma-id={isVariant2 ? "node-36_4140" : "node-36_4127"}>
                La stratégie de marque, quand devient-elle vraiement nécessaire pour votre projet ?
              </p>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[color:var(--gris,#5e5e5e)] w-full" data-figma-id={isVariant2 ? "node-36_4141" : "node-36_4128"}>{`On combine la réflexion de marque avec l'exécution technique. La plupart des agences vous font un logo ou un site web et vous souhaitent bonne chance. `}</p>
            </div>
            <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] text-[color:var(--gris,#5e5e5e)] whitespace-normal" data-figma-id={isVariant2 ? "node-36_4142" : "node-36_4129"}>
              4min de lecture
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}