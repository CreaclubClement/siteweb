// Source: Figma 21:2562; fluid layout adaptation.
type CardServiceIdentiteVisuelleDesktopProps = {
  className?: string;
  property1?: "Variant2" | "Variant3";
};

export default function CardServiceIdentiteVisuelleDesktop({ className, property1 = "Variant2" }: CardServiceIdentiteVisuelleDesktopProps) {
  const isVariant3 = property1 === "Variant3";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative w-full"} data-figma-id={isVariant3 ? "node-21_2622" : "node-21_2575"}>
      <div className={`absolute bg-[var(--accent,#d9ff8e)] h-[200px] left-[444px] top-0 ${isVariant3 ? "w-full" : "w-0"}`} data-figma-id={isVariant3 ? "node-21_2623" : "node-21_2576"} />
      <div className="content-center flex flex-wrap gap-[173px] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-21_2624" : "node-21_2577"}>
        <div className="content-stretch flex gap-[var(--l,24px)] h-[200px] items-center relative shrink-0" data-figma-id={isVariant3 ? "node-21_2625" : "node-21_2578"}>
          <div className="h-[200px] relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-21_2626" : "node-21_2591"} data-name="IMG_1473 3" />
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-figma-id={isVariant3 ? "node-21_2627" : "node-21_2580"}>
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)]" data-figma-id={isVariant3 ? "node-21_2628" : "node-21_2581"}>
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-figma-id={isVariant3 ? "node-21_2629" : "node-21_2582"}>
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-figma-id={isVariant3 ? "node-21_2630" : "node-21_2583"}>{`Comprendre avant d'agir.`}</p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-figma-id={isVariant3 ? "node-21_2631" : "node-21_2584"}>
                  Identité visuelle
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-figma-id={isVariant3 ? "node-21_2632" : "node-21_2585"}>{`Nous transformons votre stratégie en un système graphique cohérent, durable et identifiable. Une identité pensée pour accompagner la croissance de votre entreprise sur l'ensemble de ses points de contact.`}</p>
            </div>
          </div>
        </div>
        <div className="[word-break:break-word] font-sans font-normal leading-[0] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant3 ? "node-21_2633" : "node-21_2586"}>
          <p className="leading-[1.4] mb-0">
            Big idea
            <br aria-hidden />
            Univers graphique
            <br aria-hidden />
            {`Logo & déclinaison`}
          </p>
          <p className="leading-[1.4] mb-0">Palette Typographique</p>
          <p className="leading-[1.4] mb-0">Palette de couleurs</p>
          <p className="leading-[1.4] mb-0">Photographies</p>
          <p className="leading-[1.4]">Direction visuelle</p>
        </div>
      </div>
    </div>
  );
}