// Source: Figma 21:569; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame418 = `${assetPathPrefix}/f60c9.png`;

type Frame364Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame364({ className, property1 = "Default" }: Frame364Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-21_570" : "node-21_550"}>
      <div className={`flex-[1_0_0] min-h-px overflow-clip relative w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-21_571" : "node-21_666"}>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[180.75%] left-0 max-w-none top-[-58.49%] w-full" src={imgFrame418} />
        </div>
        <div className={`content-stretch flex gap-[12px] items-center ${isVariant2 ? "relative shrink-0" : "absolute left-[75px] top-[481px]"}`} data-figma-id={isVariant2 ? "node-21_572" : "node-21_667"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-21_573" : "node-21_668"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_574" : "node-21_669"}>
              Identité visuelle
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-21_575" : "node-21_670"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_576" : "node-21_671"}>
              Stratégie de marque
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-21_577" : "node-21_672"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_578" : "node-21_673"}>
              Expérience digitale
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_579" : "node-21_543"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-21_580" : "node-21_544"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_581" : "node-21_545"}>
            Lucas Drifter
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-21_582" : "node-21_546"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-21_583" : "node-21_547"}>
              REBRANDING
            </p>
          </div>
        </div>
        <div className="content-stretch flex items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_584" : "node-21_548"}>
          <p className="[word-break:break-word] font-sans font-light leading-[normal] relative shrink-0 text-[#5e5e5e] text-[16px] w-full" data-figma-id={isVariant2 ? "node-21_585" : "node-21_549"}>{`Créer une identité sobre et durable, à l'image d'un savoir-faire artisanal.`}</p>
        </div>
      </div>
    </div>
  );
}