// Source: Figma 114:3109; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame397 = `${assetPathPrefix}/48e72.png`;

type Frame445Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame445({ className, property1 = "Default" }: Frame445Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-114_3125" : "node-114_3110"}>
      <div className={`h-[389px] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-114_3126" : "node-114_3111"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame397} />
        <div className={`content-stretch flex gap-[12px] items-center justify-end ${isVariant2 ? "relative shrink-0" : "absolute left-[255px] top-[395px]"}`} data-figma-id={isVariant2 ? "node-114_3127" : "node-114_3112"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-114_3128" : "node-114_3113"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3129" : "node-114_3114"}>
              Identité visuelle
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-114_3130" : "node-114_3115"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3131" : "node-114_3116"}>
              Stratégie de marque
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-114_3132" : "node-114_3117"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3133" : "node-114_3118"}>
              Expérience digitale
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-114_3134" : "node-114_3119"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-114_3135" : "node-114_3120"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-114_3136" : "node-114_3121"}>
            Active Life
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-114_3137" : "node-114_3122"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-114_3138" : "node-114_3123"}>
              REBRANDING
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] min-w-full relative shrink-0 text-[#5e5e5e] text-[16px] w-[min-content]" data-figma-id={isVariant2 ? "node-114_3139" : "node-114_3124"}>{`Créer une communication capable de capter l'attention en quelques secondes.`}</p>
      </div>
    </div>
  );
}