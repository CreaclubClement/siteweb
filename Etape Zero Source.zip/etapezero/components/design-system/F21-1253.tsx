// Source: Figma 21:1253; fluid layout adaptation.
type BoutonPrimaryProps = {
  className?: string;
  property1?: "Default" | "Hober";
};

export default function BoutonPrimary({ className, property1 = "Default" }: BoutonPrimaryProps) {
  const isHober = property1 === "Hober";
  return (
    <div className={className || `content-stretch flex items-center justify-center p-[8px] relative ${isHober ? "bg-[var(--gris-clair,#ededed)]" : "bg-[var(--accent,#d9ff8e)]"}`} data-figma-id={isHober ? "node-21_1254" : "node-21_1252"}>
      <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal" data-figma-id={isHober ? "node-21_1255" : "node-21_1251"}>
        Nous contacter
      </p>
    </div>
  );
}