// Source: Figma 21:1544; fluid layout adaptation.
type Frame426Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame426({ className, property1 = "Default" }: Frame426Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[110px]"} data-figma-id={isVariant2 ? "node-21_1548" : "node-21_1545"}>
      <p className={`[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] ${isVariant2 ? "whitespace-normal" : "max-w-full w-[110px]"}`} data-figma-id={isVariant2 ? "node-21_1549" : "node-21_1546"}>
        Mentions légales
      </p>
      <div className={`bg-[var(--noir,#252525)] h-px relative shrink-0 ${isVariant2 ? "w-full" : "w-0"}`} data-figma-id={isVariant2 ? "node-21_1550" : "node-21_1547"} />
    </div>
  );
}