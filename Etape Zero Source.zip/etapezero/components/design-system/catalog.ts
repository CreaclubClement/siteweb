"use client";
import type { ComponentType } from "react";
import F21_490 from "./F21-490";
import F114_2901 from "./F114-2901";
import F122_1541 from "./F122-1541";
import F21_569 from "./F21-569";
import F122_1588 from "./F122-1588";
import F114_2948 from "./F114-2948";
import F21_632 from "./F21-632";
import F114_3015 from "./F114-3015";
import F127_3294 from "./F127-3294";
import F21_693 from "./F21-693";
import F122_1685 from "./F122-1685";
import F114_3191 from "./F114-3191";
import F21_775 from "./F21-775";
import F114_3226 from "./F114-3226";
import F127_3434 from "./F127-3434";
import F21_819 from "./F21-819";
import F114_3109 from "./F114-3109";
import F127_3357 from "./F127-3357";
import F21_886 from "./F21-886";
import F114_3062 from "./F114-3062";
import F122_1638 from "./F122-1638";
import F21_949 from "./F21-949";
import F114_3140 from "./F114-3140";
import F21_990 from "./F21-990";
import F36_4027 from "./F36-4027";
import F21_1049 from "./F21-1049";
import F36_4078 from "./F36-4078";
import F21_1105 from "./F21-1105";
import F21_1122 from "./F21-1122";
import F36_4116 from "./F36-4116";
import F21_1318 from "./F21-1318";
import F21_1438 from "./F21-1438";
import F21_1459 from "./F21-1459";
import F21_1480 from "./F21-1480";
import F21_1501 from "./F21-1501";
import F21_1515 from "./F21-1515";
import F21_1529 from "./F21-1529";
import F21_1544 from "./F21-1544";
import F21_1639 from "./F21-1639";
import F21_1661 from "./F21-1661";
import F21_1675 from "./F21-1675";
import F21_1689 from "./F21-1689";
import F21_1703 from "./F21-1703";
import F21_1716 from "./F21-1716";
import F21_1566 from "./F21-1566";
import F21_1611 from "./F21-1611";
import F21_1837 from "./F21-1837";
import F21_1867 from "./F21-1867";
import F21_1872 from "./F21-1872";
import F114_2777 from "./F114-2777";
import F122_1822 from "./F122-1822";
import F122_2051 from "./F122-2051";
import F114_2830 from "./F114-2830";
import F21_2522 from "./F21-2522";
import F127_2660 from "./F127-2660";
import F127_2725 from "./F127-2725";
import F127_2806 from "./F127-2806";
import F97_2449 from "./F97-2449";
import F21_2562 from "./F21-2562";
import F97_2375 from "./F97-2375";
import F21_2676 from "./F21-2676";
import F97_2229 from "./F97-2229";
import F21_1253 from "./F21-1253";
import F36_2973 from "./F36-2973";
import F21_1261 from "./F21-1261";
import F102_1858 from "./F102-1858";
import F149_2367 from "./F149-2367";
import F114_1650 from "./F114-1650";
import F114_1659 from "./F114-1659";
import F114_1671 from "./F114-1671";
import F114_1677 from "./F114-1677";
import F114_1683 from "./F114-1683";
import F36_3014 from "./F36-3014";
import F36_3242 from "./F36-3242";
import F36_3349 from "./F36-3349";
import F36_3479 from "./F36-3479";
import F36_4811 from "./F36-4811";
import F36_4859 from "./F36-4859";
import F36_4872 from "./F36-4872";
import F36_4886 from "./F36-4886";
import F36_4950 from "./F36-4950";
import F36_4960 from "./F36-4960";
import F36_4970 from "./F36-4970";
import F36_4901 from "./F36-4901";
import F77_2045 from "./F77-2045";
import F2034_4482 from "./F2034-4482";
export type Entry = { id:string;name:string;family:string;variants:string[];defaultVariant:string;w:number;h:number;component:ComponentType<any> };
export const catalog: Entry[] = [
{"id": "21:490", "name": "Card projet home version 3", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 853, "h": 571, component:F21_490},
{"id": "114:2901", "name": "Card projet grid \"Listing\" Amoual", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 571, component:F114_2901},
{"id": "122:1541", "name": "Card projet Mobile", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 571, component:F122_1541},
{"id": "21:569", "name": "Frame 364", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 487, "h": 571, component:F21_569},
{"id": "122:1588", "name": "Card projet home version 2", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 571, component:F122_1588},
{"id": "114:2948", "name": "Frame 442", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 571, component:F114_2948},
{"id": "21:632", "name": "Frame 387", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 315, "h": 481, component:F21_632},
{"id": "114:3015", "name": "Card projet grid \"Listing\" U-tragulinu", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3015},
{"id": "127:3294", "name": "Card projet Mobile", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 481, component:F127_3294},
{"id": "21:693", "name": "Frame 388", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 694, "h": 481, component:F21_693},
{"id": "122:1685", "name": "Frame 427322454", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 481, component:F122_1685},
{"id": "114:3191", "name": "Frame 447", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3191},
{"id": "21:775", "name": "Frame 389", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 315, "h": 481, component:F21_775},
{"id": "114:3226", "name": "Frame 448", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3226},
{"id": "127:3434", "name": "Card projet Mobile", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 481, component:F127_3434},
{"id": "21:819", "name": "Frame 390", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 315, "h": 481, component:F21_819},
{"id": "114:3109", "name": "Frame 445", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3109},
{"id": "127:3357", "name": "Card projet Mobile", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 481, component:F127_3357},
{"id": "21:886", "name": "Card projet home version 1", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 694, "h": 481, component:F21_886},
{"id": "114:3062", "name": "Card projet grid \"Listing\" PB cosmetics", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3062},
{"id": "122:1638", "name": "Frame 427322453", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 481, component:F122_1638},
{"id": "21:949", "name": "Card projet home version 2", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 315, "h": 481, component:F21_949},
{"id": "114:3140", "name": "Card projet home version 1", "family": "Projets", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 670, "h": 481, component:F114_3140},
{"id": "21:990", "name": "Frame 8", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 425, component:F21_990},
{"id": "36:4027", "name": "Frame 435", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 553, component:F36_4027},
{"id": "21:1049", "name": "Frame 13", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 425, component:F21_1049},
{"id": "36:4078", "name": "Card article V2", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 553, component:F36_4078},
{"id": "21:1105", "name": "Frame 11", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 425, component:F21_1105},
{"id": "21:1122", "name": "Frame 10", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 425, component:F21_1122},
{"id": "36:4116", "name": "Card article V1", "family": "Articles", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 324, "h": 553, component:F36_4116},
{"id": "21:1318", "name": "Frame 38", "family": "Navigation", "variants": ["Desktop Version", "Mobile Version"], "defaultVariant": "Desktop Version", "w": 1440, "h": 141, component:F21_1318},
{"id": "21:1438", "name": "Frame 420", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 117, "h": 23, component:F21_1438},
{"id": "21:1459", "name": "Frame 421", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 132, "h": 23, component:F21_1459},
{"id": "21:1480", "name": "Frame 422", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 103, "h": 23, component:F21_1480},
{"id": "21:1501", "name": "Frame 423", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 66, "h": 23, component:F21_1501},
{"id": "21:1515", "name": "Frame 424", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 53, "h": 23, component:F21_1515},
{"id": "21:1529", "name": "Frame 425", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 55, "h": 23, component:F21_1529},
{"id": "21:1544", "name": "Frame 426", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 110, "h": 23, component:F21_1544},
{"id": "21:1639", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 46, "h": 28, component:F21_1639},
{"id": "21:1661", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 56, "h": 28, component:F21_1661},
{"id": "21:1675", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 61, "h": 28, component:F21_1675},
{"id": "21:1689", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 64, "h": 28, component:F21_1689},
{"id": "21:1703", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 64, "h": 28, component:F21_1703},
{"id": "21:1716", "name": "Hover link effect", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 64, "h": 28, component:F21_1716},
{"id": "21:1566", "name": "Logo animation Header", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 138.06475830078125, "h": 26.474811553955078, component:F21_1566},
{"id": "21:1611", "name": "Logo animation Header", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 110, "h": 21.093212127685547, component:F21_1611},
{"id": "21:1837", "name": "CTA contact Header", "family": "Boutons", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 199, "h": 68, component:F21_1837},
{"id": "21:1867", "name": "Frame 434", "family": "Boutons", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 129, "h": 38, component:F21_1867},
{"id": "21:1872", "name": "Frame 14", "family": "Boutons", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 131, "h": 38, component:F21_1872},
{"id": "114:2777", "name": "Header Desktop ", "family": "Navigation", "variants": ["Default", "Dropdown services"], "defaultVariant": "Default", "w": 1440, "h": 68, component:F114_2777},
{"id": "122:1822", "name": "Header Mobile", "family": "Navigation", "variants": ["Close", "Open"], "defaultVariant": "Close", "w": 375, "h": 78, component:F122_1822},
{"id": "122:2051", "name": "Dropdown services", "family": "Navigation", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 343, "h": 144, component:F122_2051},
{"id": "114:2830", "name": "Frame 438", "family": "Boutons", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 148, "h": 34, component:F114_2830},
{"id": "21:2522", "name": "Card service Stratégie de marque Desktop", "family": "Services", "variants": ["Default", "Hover"], "defaultVariant": "Default", "w": 1356, "h": 200, component:F21_2522},
{"id": "127:2660", "name": "Frame 427322456", "family": "Services", "variants": ["Default", "On click"], "defaultVariant": "Default", "w": 343, "h": 547, component:F127_2660},
{"id": "127:2725", "name": "Card service Expérience Digital Mobile", "family": "Services", "variants": ["Default", "Active"], "defaultVariant": "Default", "w": 343, "h": 569, component:F127_2725},
{"id": "127:2806", "name": "Listing service Mobile", "family": "Services", "variants": ["Default", "Active"], "defaultVariant": "Default", "w": 343, "h": 569, component:F127_2806},
{"id": "97:2449", "name": "Card service Stratégie de marque Desktop page à propos", "family": "Services", "variants": ["Default", "Active"], "defaultVariant": "Default", "w": 737, "h": 200, component:F97_2449},
{"id": "21:2562", "name": "Card service Identité visuelle Desktop", "family": "Services", "variants": ["Variant2", "Variant3"], "defaultVariant": "Variant2", "w": 1356, "h": 200, component:F21_2562},
{"id": "97:2375", "name": "Card service Identité visuelle Desktop page à propos", "family": "Services", "variants": ["Variant2", "Variant3"], "defaultVariant": "Variant2", "w": 737, "h": 200, component:F97_2375},
{"id": "21:2676", "name": "Card service Expérience Digital Desktop", "family": "Services", "variants": ["Default", "Hover"], "defaultVariant": "Default", "w": 1356, "h": 200, component:F21_2676},
{"id": "97:2229", "name": "Card service Expérience Digital Desktop page à propos", "family": "Services", "variants": ["Variant2", "Variant3"], "defaultVariant": "Variant2", "w": 737, "h": 200, component:F97_2229},
{"id": "21:1253", "name": "Bouton primary", "family": "Boutons", "variants": ["Default", "Hober"], "defaultVariant": "Default", "w": 129, "h": 38, component:F21_1253},
{"id": "36:2973", "name": "Bouton RDV", "family": "Boutons", "variants": ["Default", "Hover"], "defaultVariant": "Default", "w": 175, "h": 38, component:F36_2973},
{"id": "21:1261", "name": "Bouton secondary", "family": "Boutons", "variants": ["Default", "Hover"], "defaultVariant": "Default", "w": 131, "h": 38, component:F21_1261},
{"id": "102:1858", "name": "Vidéo service mobile", "family": "Médias", "variants": ["close", "open"], "defaultVariant": "close", "w": 343, "h": 562, component:F102_1858},
{"id": "149:2367", "name": "Vidéo service mobile", "family": "Médias", "variants": ["Open", "Close"], "defaultVariant": "Open", "w": 978, "h": 1223, component:F149_2367},
{"id": "114:1650", "name": "Frame 427322439", "family": "FAQ", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 526, "h": 122, component:F114_1650},
{"id": "114:1659", "name": "Frame 427322440", "family": "FAQ", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 515, "h": 122, component:F114_1659},
{"id": "114:1671", "name": "Frame 427322441", "family": "FAQ", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 386, "h": 142, component:F114_1671},
{"id": "114:1677", "name": "Frame 427322442", "family": "FAQ", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 362, "h": 162, component:F114_1677},
{"id": "114:1683", "name": "FAQ dropdown", "family": "FAQ", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 490, "h": 122, component:F114_1683},
{"id": "36:3014", "name": "Formulaire de contact", "family": "Formulaires", "variants": ["Default", "Variant3", "Variant2"], "defaultVariant": "Default", "w": 1398, "h": 394, component:F36_3014},
{"id": "36:3242", "name": "Dropdowns form", "family": "Formulaires", "variants": ["Dropdown | Regular", "Dropdown | Focus", "Dropdown | Open"], "defaultVariant": "Dropdown | Regular", "w": 368, "h": 64, component:F36_3242},
{"id": "36:3349", "name": "Dropdowns form 2", "family": "Formulaires", "variants": ["Dropdown | Regular", "Dropdown | Focus", "Dropdown | Open"], "defaultVariant": "Dropdown | Regular", "w": 368, "h": 64, component:F36_3349},
{"id": "36:3479", "name": "Select form", "family": "Formulaires", "variants": ["Default", "Variant2"], "defaultVariant": "Default", "w": 15, "h": 15, component:F36_3479},
{"id": "36:4811", "name": "Frame 362", "family": "Filtres", "variants": ["Non sélectioner", "Sélectionner"], "defaultVariant": "Non sélectioner", "w": 169, "h": 30, component:F36_4811},
{"id": "36:4859", "name": "Filtre Positionnement", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 130, "h": 30, component:F36_4859},
{"id": "36:4872", "name": "Filtre rebranding", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 100, "h": 30, component:F36_4872},
{"id": "36:4886", "name": "Filtre Valeur perçu", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 118, "h": 30, component:F36_4886},
{"id": "36:4950", "name": "Filtre Système graphique", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 158, "h": 30, component:F36_4950},
{"id": "36:4960", "name": "Filtre Expérience Digitale", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 155, "h": 30, component:F36_4960},
{"id": "36:4970", "name": "Filtre Buissness", "family": "Filtres", "variants": ["Sélectionner", "Non sélectioner"], "defaultVariant": "Sélectionner", "w": 83, "h": 30, component:F36_4970},
{"id": "36:4901", "name": "Filtre ARTICLE", "family": "Filtres", "variants": ["Default", "Variant2", "Variant3", "Variant4", "Variant5", "Variant6"], "defaultVariant": "Default", "w": 772, "h": 62, component:F36_4901},
{"id": "77:2045", "name": "Filtre Listing projet", "family": "Filtres", "variants": ["Default", "Variant2", "Variant3"], "defaultVariant": "Default", "w": 349, "h": 62, component:F77_2045},
{"id": "2034:4482", "name": "Option", "family": "Formulaires", "variants": ["HOver", "Classique"], "defaultVariant": "HOver", "w": 368, "h": 40, component:F2034_4482},
];