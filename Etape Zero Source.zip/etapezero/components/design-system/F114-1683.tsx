// Source: Figma 114:1683; fluid layout adaptation.
type FaqDropdownProps = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function FaqDropdown({ className, property1 = "Default" }: FaqDropdownProps) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || `border-[var(--gris-clair,#ededed)] border-b border-solid content-stretch flex flex-col gap-[var(--m,16px)] items-center justify-center relative ${isVariant2 ? "p-[var(--s,8px)]" : '[word-break:break-word] font-sans font-normal leading-[1.4] pb-[var(--m,16px)] pt-[var(--s,8px)] px-[var(--s,8px)]'}`} data-figma-id={isVariant2 ? "node-114_1687" : "node-114_1684"}>
      <p className={`relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal ${isVariant2 ? '[word-break:break-word] font-sans font-normal leading-[1.4]' : ""}`} data-figma-id={isVariant2 ? "node-114_1688" : "node-114_1685"}>{`Peut-on poursuivre ensuite avec l'identité visuelle et le site web ?`}</p>
      {property1 === "Default" && (
        <p className="min-w-full relative shrink-0 text-[14px] text-[color:var(--gris,#5e5e5e)] text-left w-[min-content]" data-node-id="114:1686">
          Oui. La stratégie constitue la première étape de notre accompagnement. Elle peut ensuite être déclinée en identité visuelle, expérience digitale et déploiement de la marque afin de garantir une parfaite cohérence.
        </p>
      )}
    </div>
  );
}