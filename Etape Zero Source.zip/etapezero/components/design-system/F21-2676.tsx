// Source: Figma 21:2676; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgImg14733 = `${assetPathPrefix}/3cf9d.png`;

type CardServiceExperienceDigitalDesktopProps = {
  className?: string;
  property1?: "Default" | "Hover";
};

export default function CardServiceExperienceDigitalDesktop({ className, property1 = "Default" }: CardServiceExperienceDigitalDesktopProps) {
  const isHover = property1 === "Hover";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative w-full"} data-figma-id={isHover ? "node-21_2689" : "node-21_2677"}>
      <div className={`absolute bg-[var(--accent,#d9ff8e)] h-[200px] left-[444px] top-0 ${isHover ? "w-full" : "w-0"}`} data-figma-id={isHover ? "node-21_2690" : "node-21_2678"} />
      <div className="content-center flex flex-wrap gap-[173px] h-[200px] items-center relative shrink-0" data-figma-id={isHover ? "node-21_2691" : "node-21_2679"}>
        <div className="content-stretch flex gap-[var(--l,24px)] h-[200px] items-center relative shrink-0" data-figma-id={isHover ? "node-21_2692" : "node-21_2680"}>
          <div className="h-[200px] relative min-w-0 w-full" data-figma-id={isHover ? "node-21_2693" : "node-21_2681"} data-name="IMG_1473 3">
            <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImg14733} />
          </div>
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-figma-id={isHover ? "node-21_2694" : "node-21_2682"}>
            <div className="[word-break:break-word] col-1 content-stretch flex flex-col font-sans gap-[12px] items-start ml-0 mt-0 relative row-1 text-[color:var(--noir,#252525)]" data-figma-id={isHover ? "node-21_2695" : "node-21_2683"}>
              <div className="content-stretch flex flex-col gap-[var(--xs,4px)] items-start relative min-w-0 w-full" data-figma-id={isHover ? "node-21_2696" : "node-21_2684"}>
                <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] w-full" data-figma-id={isHover ? "node-21_2697" : "node-21_2685"}>
                  Prolonger la marque dans le digital.
                </p>
                <p className="font-normal leading-[1.25] relative shrink-0 text-[24px] w-full" data-figma-id={isHover ? "node-21_2698" : "node-21_2686"}>
                  Expérience digitale
                </p>
              </div>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[16px] w-full" data-figma-id={isHover ? "node-21_2699" : "node-21_2687"}>
                Nous concevons des expériences digitales qui traduisent votre positionnement et accompagnent vos objectifs. Chaque interface est pensée pour créer une expérience fluide, cohérente et orientée conversion.
              </p>
            </div>
          </div>
        </div>
        <div className="[word-break:break-word] font-sans font-normal leading-[0] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isHover ? "node-21_2700" : "node-21_2688"}>
          <p className="leading-[1.4] mb-0">
            UX/UI Design
            <br aria-hidden />
            Parcours utilisateur
            <br aria-hidden />
            Expérience client
          </p>
          <p className="leading-[1.4] mb-0">Product design</p>
          <p className="leading-[1.4] mb-0">Dev Webflow</p>
          <p className="leading-[1.4] mb-0">Dev Shopify</p>
          <p className="leading-[1.4]">Dev sur-mesure</p>
        </div>
      </div>
    </div>
  );
}