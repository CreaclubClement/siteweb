// Source: Figma 122:1588; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame418 = `${assetPathPrefix}/f60c9.png`;

type CardProjetHomeVersion2Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardProjetHomeVersion2({ className, property1 = "Default" }: CardProjetHomeVersion2Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-122_1605" : "node-122_1589"}>
      <div className={`flex-[1_0_0] min-h-px overflow-clip relative w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-122_1606" : "node-122_1590"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame418} />
        <div className={`content-stretch flex gap-[12px] ${isVariant2 ? "flex-col items-end justify-end relative shrink-0" : "absolute items-center left-[75px] top-[481px]"}`} data-figma-id={isVariant2 ? "node-122_1607" : "node-122_1591"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1608" : "node-122_1592"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1609" : "node-122_1593"}>
              Identité visuelle
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1610" : "node-122_1594"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1611" : "node-122_1595"}>
              Stratégie de marque
            </p>
          </div>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-122_1612" : "node-122_1596"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1613" : "node-122_1597"}>
              Expérience digitale
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start justify-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-122_1614" : "node-122_1598"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-122_1615" : "node-122_1599"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-122_1616" : "node-122_1600"}>
            Lucas Drifter
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-122_1617" : "node-122_1601"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-122_1618" : "node-122_1602"}>
              REBRANDING
            </p>
          </div>
        </div>
        <div className="content-stretch flex items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-122_1619" : "node-122_1603"}>
          <p className="[word-break:break-word] font-sans font-light leading-[normal] relative shrink-0 text-[#5e5e5e] text-[16px] w-full" data-figma-id={isVariant2 ? "node-122_1620" : "node-122_1604"}>{`Créer une identité sobre et durable, à l'image d'un savoir-faire artisanal.`}</p>
        </div>
      </div>
    </div>
  );
}