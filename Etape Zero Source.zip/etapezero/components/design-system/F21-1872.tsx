// Source: Figma 21:1872; fluid layout adaptation.
type Frame14Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame14({ className, property1 = "Default" }: Frame14Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || `content-stretch flex items-center justify-center p-[8px] relative ${isVariant2 ? "bg-[var(--accent,#d9ff8e)]" : "bg-[var(--gris-clair,#ededed)]"}`} data-figma-id={isVariant2 ? "node-21_1875" : "node-21_1873"}>
      <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_1876" : "node-21_1874"}>
        Voir nos projets
      </p>
    </div>
  );
}