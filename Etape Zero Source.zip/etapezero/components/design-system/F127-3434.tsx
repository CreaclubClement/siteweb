// Source: Figma 127:3434; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgFrame396 = `${assetPathPrefix}/77725.png`;

type CardProjetMobileProps = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function CardProjetMobile({ className, property1 = "Default" }: CardProjetMobileProps) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[16px] h-auto items-start justify-center relative w-full"} data-figma-id={isVariant2 ? "node-127_3446" : "node-127_3435"}>
      <div className={`h-[389px] overflow-clip relative min-w-0 w-full ${isVariant2 ? "content-stretch flex flex-col items-end justify-end p-[12px]" : ""}`} data-figma-id={isVariant2 ? "node-127_3447" : "node-127_3436"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgFrame396} />
        <div className={`content-stretch flex ${isVariant2 ? "flex-col items-end justify-end relative shrink-0" : "absolute items-center left-[194px] top-[391px]"}`} data-figma-id={isVariant2 ? "node-127_3448" : "node-127_3437"}>
          <div className="bg-white content-stretch flex items-center justify-center p-[4px] relative shrink-0" data-figma-id={isVariant2 ? "node-127_3449" : "node-127_3438"}>
            <p className="[word-break:break-word] font-sans font-normal leading-[normal] relative shrink-0 text-[14px] text-black text-center whitespace-normal" data-figma-id={isVariant2 ? "node-127_3450" : "node-127_3439"}>
              Identité visuelle
            </p>
          </div>
        </div>
      </div>
      <div className="content-stretch flex flex-col gap-[8px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-127_3451" : "node-127_3440"}>
        <div className="content-stretch flex gap-[12px] items-center relative shrink-0" data-figma-id={isVariant2 ? "node-127_3452" : "node-127_3441"}>
          <p className="[word-break:break-word] font-sans font-medium leading-[normal] relative shrink-0 text-[#252525] text-[16px] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-127_3453" : "node-127_3442"}>
            SoleSpace
          </p>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[#d9ff8e]" : "bg-[#f1f1f1]"}`} data-figma-id={isVariant2 ? "node-127_3454" : "node-127_3443"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[#252525] text-[14px] text-center tracking-[-0.28px] whitespace-normal" data-figma-id={isVariant2 ? "node-127_3455" : "node-127_3444"}>
              LANCEMENT
            </p>
          </div>
        </div>
        <p className="[word-break:break-word] font-sans font-light leading-[normal] min-w-full relative shrink-0 text-[#5e5e5e] text-[16px] w-[min-content]" data-figma-id={isVariant2 ? "node-127_3456" : "node-127_3445"}>{`Poser les bases d'une marque ambitieuse dès son lancement.`}</p>
      </div>
    </div>
  );
}