// Source: Figma 122:1822; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgUuidC594854B938E41CdA6552Ad5Ea221458 = `${assetPathPrefix}/8c946.svg`;
const img = `${assetPathPrefix}/da608.svg`;

type HoverLinkEffectProps = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect({ className, property1 = "Default" }: HoverLinkEffectProps) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative"} data-node-id="21:1690">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1691" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1692">
        Le journal
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1693" />
    </div>
  );
}

type HoverLinkEffect1Props = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect1({ className, property1 = "Default" }: HoverLinkEffect1Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative"} data-node-id="21:1676">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1677" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1678">
        Le Studio
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1679" />
    </div>
  );
}

type HoverLinkEffect2Props = {
  className?: string;
  property1?: "Default";
};

function HoverLinkEffect2({ className, property1 = "Default" }: HoverLinkEffect2Props) {
  return (
    <div className={className || "content-stretch flex flex-col gap-[var(--xs,4px)] items-end relative max-w-full w-[46px]"} data-node-id="21:1640">
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1651" />
      <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[14px] text-[color:var(--noir,#252525)] whitespace-normal" data-node-id="21:1641">
        Projets
      </p>
      <div className="bg-[var(--noir,#252525)] h-px relative shrink-0 w-0" data-node-id="21:1642" />
    </div>
  );
}

type HeaderMobileProps = {
  className?: string;
  property1?: "Close" | "Open";
};

export default function HeaderMobile({ className, property1 = "Close" }: HeaderMobileProps) {
  const isClose = property1 === "Close";
  const isOpen = property1 === "Open";
  return (
    <div className={className || `bg-[var(--blanc,white)] content-stretch flex relative w-full ${isOpen ? "flex-col h-auto items-end justify-between pt-[20px]" : "h-[78px] items-start justify-center px-[var(--m,16px)] py-[20px]"}`} data-figma-id={isOpen ? "node-122_1997" : "node-122_1823"}>
      <div className={`content-stretch flex relative shrink-0 ${isOpen ? "flex-col gap-[40px] items-start px-[var(--m,16px)] w-full" : "items-center justify-center"}`} data-figma-id={isOpen ? "node-122_2307" : "node-122_1964"}>
        <div className={`flex items-center ${isOpen ? "content-stretch h-[38px] justify-center relative min-w-0 w-full" : "flex-row self-stretch"}`} data-figma-id={isOpen ? "node-122_1998" : "node-122_1976"}>
          <div className={`content-stretch flex h-full items-center relative ${isOpen ? "flex-[1_0_0] justify-between min-w-px" : "gap-[97px] shrink-0"}`} data-figma-id={isOpen ? "node-122_1999" : undefined}>
            <div className={`bg-[var(--gris-clair,#ededed)] content-stretch cursor-pointer flex items-center justify-center p-[8px] relative shrink-0 ${isOpen ? "h-full max-w-full w-[38px]" : "max-w-full w-[59px]"}`} data-figma-id={isOpen ? "node-122_2000" : "node-122_1900"}>
              {isClose && (
                <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal" data-node-id="122:1901">
                  Menu
                </p>
              )}
              {isOpen && (
                <div className="flex items-center justify-center relative shrink-0 size-[14px]" data-node-id="122:2037">
                  <div className="-rotate-45 flex-none">
                    <div className="relative size-[9.9px]" data-name="+">
                      <img alt="" className="absolute block inset-0 max-w-none size-full" src={img} />
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-figma-id={isOpen ? "node-122_2002" : "node-122_1902"}>
              <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-0 mt-0 place-items-start relative row-1" data-figma-id={isOpen ? "node-122_2003" : "node-122_1903"}>
                <div className="col-1 ml-0 mt-0 relative row-1 size-[32px]" data-figma-id={isOpen ? "node-122_2004" : "node-122_1904"} data-name="uuid-c594854b-938e-41cd-a655-2ad5ea221458">
                  <img alt="" className="absolute block inset-0 max-w-none size-full" src={imgUuidC594854B938E41CdA6552Ad5Ea221458} />
                </div>
              </div>
            </div>
            {isClose && (
              <div className="content-stretch flex h-full items-center justify-center relative shrink-0" data-node-id="122:1973">
                <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center max-w-full w-[59px]" data-node-id="122:1908">
                  Contact
                </p>
              </div>
            )}
          </div>
        </div>
        {isOpen && (
          <div className="content-stretch flex flex-col gap-[var(--m,16px)] items-start justify-center relative min-w-0 w-full" data-node-id="122:2008">
            <HoverLinkEffect2 className="content-stretch flex flex-col gap-[var(--xs,4px)] h-[34px] items-end relative shrink-0 max-w-full w-[46px]" />
            <div className="border-[var(--gris-clair,#ededed)] border-b border-solid content-stretch cursor-pointer flex flex-col gap-[var(--m,16px)] items-start py-[var(--s,8px)] relative min-w-0 w-full" data-node-id="122:2078" data-name="Dropdown services">
              <div className="[word-break:break-word] content-stretch flex font-sans font-[450] gap-[var(--xs,4px)] items-start leading-[normal] relative shrink-0 text-[14px] whitespace-normal" data-node-id="I122:2078;122:2065">
                <p className="relative shrink-0 text-[color:var(--noir,#252525)] text-center" data-node-id="I122:2078;122:2066">
                  Services
                </p>
                <p className="relative shrink-0 text-black text-left" data-node-id="I122:2078;122:2067">
                  +
                </p>
              </div>
            </div>
            <HoverLinkEffect1 className="content-stretch flex flex-col gap-[var(--xs,4px)] h-[34px] items-end relative shrink-0" />
            <HoverLinkEffect className="content-stretch flex flex-col gap-[var(--xs,4px)] h-[34px] items-end relative shrink-0" />
          </div>
        )}
      </div>
      {isOpen && (
        <div className="bg-[var(--accent,#d9ff8e)] content-stretch flex gap-[var(--xs,4px)] h-[68px] items-start p-[var(--s,8px)] relative rounded-tl-[8px] shrink-0 max-w-full w-[199px]" data-node-id="122:2303" data-name="CTA contact Header">
          <p className="[word-break:break-word] font-sans font-normal leading-[1.2] relative shrink-0 text-[32px] text-[color:var(--noir,#252525)] text-right tracking-[-0.96px] whitespace-normal" data-node-id="I122:2303;21:1835">
            Contact
          </p>
          <div className="absolute bg-[var(--noir,#252525)] h-[68px] left-0 rounded-bl-[var(--s,8px)] top-0 w-0" data-node-id="I122:2303;21:1847" />
        </div>
      )}
    </div>
  );
}