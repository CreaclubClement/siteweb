// Source: Figma 21:1867; fluid layout adaptation.
type Frame434Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame434({ className, property1 = "Default" }: Frame434Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || `content-stretch flex items-center justify-center p-[8px] relative ${isVariant2 ? "bg-[var(--gris-clair,#ededed)]" : "bg-[var(--accent,#d9ff8e)]"}`} data-figma-id={isVariant2 ? "node-21_1870" : "node-21_1868"}>
      <p className="[word-break:break-word] font-sans font-normal leading-[1.4] relative shrink-0 text-[16px] text-[color:var(--noir,#252525)] text-center whitespace-normal" data-figma-id={isVariant2 ? "node-21_1871" : "node-21_1869"}>
        Nous contacter
      </p>
    </div>
  );
}