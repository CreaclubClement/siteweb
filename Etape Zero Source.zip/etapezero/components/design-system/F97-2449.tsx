import Default from "./V97-2450";
import Active from "./V97-2462";
export default function Component({property1="Default"}:{property1?:string}){return property1==="Active"?<Active/>:<Default/>;}
