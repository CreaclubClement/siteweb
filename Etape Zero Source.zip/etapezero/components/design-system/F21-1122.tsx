// Source: Figma 21:1122; fluid layout adaptation.
const assetPathPrefix = "/assets/figma";
const imgRectangle6 = `${assetPathPrefix}/62e58.png`;

type Frame10Props = {
  className?: string;
  property1?: "Default" | "Variant2";
};

export default function Frame10({ className, property1 = "Default" }: Frame10Props) {
  const isVariant2 = property1 === "Variant2";
  return (
    <div className={className || "content-stretch flex flex-col gap-[12px] items-start relative w-full"} data-figma-id={isVariant2 ? "node-21_1123" : "node-21_1121"}>
      <div className="h-[224px] relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_1124" : "node-21_1091"}>
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgRectangle6} />
      </div>
      <div className="content-stretch flex flex-col gap-[12px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_1125" : "node-21_1092"}>
        <div className="content-stretch flex gap-[8px] items-center relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_1126" : "node-21_1093"}>
          <div className={`content-stretch flex items-center justify-center p-[4px] relative shrink-0 ${isVariant2 ? "bg-[var(--accent,#d9ff8e)]" : "bg-[var(--gris-clair,#ededed)]"}`} data-figma-id={isVariant2 ? "node-21_1127" : "node-21_1094"}>
            <p className="[word-break:break-word] font-sans font-[450] leading-[normal] relative shrink-0 text-[12px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant2 ? "node-21_1128" : "node-21_1095"}>
              IDENTITÉ VISUELLE
            </p>
          </div>
          <p className="[word-break:break-word] font-sans font-[450] leading-[1.4] relative shrink-0 text-[12px] text-[color:var(--noir,#252525)] whitespace-normal" data-figma-id={isVariant2 ? "node-21_1129" : "node-21_1096"}>
            12 juillet 2025
          </p>
        </div>
        <div className="content-stretch flex flex-col items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_1130" : "node-21_1097"}>
          <div className="[word-break:break-word] content-stretch flex flex-col font-sans gap-[12px] items-start relative min-w-0 w-full" data-figma-id={isVariant2 ? "node-21_1131" : "node-21_1098"}>
            <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 text-[14px] w-full" data-figma-id={isVariant2 ? "node-21_1132" : "node-21_1099"}>
              <p className={`font-[450] leading-[normal] relative shrink-0 text-[color:var(--noir,#252525)] w-full ${isVariant2 ? "[text-underline-position:from-font] decoration-from-font decoration-solid underline" : ""}`} data-figma-id={isVariant2 ? "node-21_1133" : "node-21_1100"}>
                La stratégie de marque, quand devient-elle vraiement nécessaire pour votre projet ?
              </p>
              <p className="font-normal leading-[1.4] relative shrink-0 text-[color:var(--gris,#5e5e5e)] w-full" data-figma-id={isVariant2 ? "node-21_1134" : "node-21_1101"}>{`On combine la réflexion de marque avec l'exécution technique. La plupart des agences vous font un logo ou un site web et vous souhaitent bonne chance. `}</p>
            </div>
            <p className="font-[450] leading-[1.4] relative shrink-0 text-[12px] text-[color:var(--gris,#5e5e5e)] whitespace-normal" data-figma-id={isVariant2 ? "node-21_1135" : "node-21_1102"}>
              4min de lecture
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}